# HUST-CS-Thesis
该模板基于华中科技大学2022春本科毕业设计公文包（计算机学院），小修了一下，可以在overleaf上正常使用，设置Compiler=XeLaTex, TeX Live version=2021。





------

以下是本科毕业设计公文包（计算机学院）原始README：

该模板是基于https://github.com/skinaze/HUSTPaperTemp  项目修订
用法大概就是写好了敲make就行。
windows环境下装个miktex然后想办法随便从哪找个make就可以
